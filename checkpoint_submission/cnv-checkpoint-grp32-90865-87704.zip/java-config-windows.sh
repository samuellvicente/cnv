 
export JAVA_HOME="/c/Program Files/Java/jdk1.7.0_80"
#/usr/lib/jvm/java-7-openjdk-amd64/
export JAVA_ROOT="/c/Program Files/Java/jdk1.7.0_80"
export JDK_HOME="/c/Program Files/Java/jdk1.7.0_80"
export JRE_HOME="/c/Program Files/Java/jdk1.7.0_80/jre"
export PATH="/c/Program Files/Java/jdk1.7.0_80/bin":$PATH
export SDK_HOME="/c/Program Files/Java/jdk1.7.0_80"
