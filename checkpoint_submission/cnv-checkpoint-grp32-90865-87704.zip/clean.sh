
# Clean up
rm instrumented/pt/ulisboa/tecnico/cnv/server/*class
rm instrumented/pt/ulisboa/tecnico/cnv/util/*class
rm instrumented/pt/ulisboa/tecnico/cnv/solver/*class
rm project/pt/ulisboa/tecnico/cnv/server/*class
rm project/pt/ulisboa/tecnico/cnv/solver/*class
rm BIT/BIT/*class