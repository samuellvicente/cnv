export JAVA_HOME=/usr/lib/jvm/java-7-openjdk/
export JAVA_ROOT=/usr/lib/jvm/java-7-openjdk/
export JDK_HOME=/usr/lib/jvm/java-7-openjdk/
export JRE_HOME=/usr/lib/jvm/java-7-openjdk/jre
export PATH=/usr/lib/jvm/java-7-openjdk/bin/:$PATH
export SDK_HOME=/usr/lib/jvm/java-7-openjdk/
